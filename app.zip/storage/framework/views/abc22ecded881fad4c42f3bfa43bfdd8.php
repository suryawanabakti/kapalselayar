<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Lengkapi Data Penumpang')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="mb-8 border-b pb-4">
                        <h3 class="text-lg font-bold text-gray-800"><?php echo e($schedule->ship->name); ?></h3>
                        <p class="text-gray-600">
                            <?php echo e(\Carbon\Carbon::parse($schedule->departure_date)->format('d M Y')); ?> |
                            <?php echo e(\Carbon\Carbon::parse($schedule->departure_time)->format('H:i')); ?> WITA
                        </p>
                        <p class="text-blue-600 font-bold mt-1">Harga: Rp
                            <?php echo e(number_format($schedule->price, 0, ',', '.')); ?> / tiket</p>
                    </div>

                    <form action="<?php echo e(route('bookings.store')); ?>" method="POST" x-data="{
                        passengers: [{ name: '', nik: '' }],
                        price: <?php echo e($schedule->price); ?>,
                        addPassenger() {
                            this.passengers.push({ name: '', nik: '' });
                        },
                        removePassenger(index) {
                            if (this.passengers.length > 1) {
                                this.passengers.splice(index, 1);
                            }
                        }
                    }">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="schedule_id" value="<?php echo e($schedule->id); ?>">

                        <div class="space-y-6">
                            <template x-for="(passenger, index) in passengers" :key="index">
                                <div class="p-4 bg-gray-50 rounded-lg border border-gray-200 relative">
                                    <div class="flex justify-between items-center mb-4">
                                        <h4 class="font-bold text-gray-700">Penumpang #<span x-text="index + 1"></span>
                                        </h4>
                                        <button type="button" @click="removePassenger(index)"
                                            x-show="passengers.length > 1" class="text-red-500 text-sm hover:underline">
                                            Hapus
                                        </button>
                                    </div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-1">Nama
                                                Lengkap</label>
                                            <input type="text" :name="`passengers[${index}][name]`"
                                                x-model="passenger.name"
                                                class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                                placeholder="Sesuai KTP" required>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-1">NIK (16
                                                Digit)</label>
                                            <input type="text" :name="`passengers[${index}][nik]`"
                                                x-model="passenger.nik"
                                                class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                                placeholder="16 Digit NIK" maxlength="16" minlength="16" required>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </div>

                        <div class="mt-6">
                            <button type="button" @click="addPassenger()"
                                class="text-blue-600 font-medium hover:text-blue-800 flex items-center">
                                <span class="text-xl mr-1">+</span> Tambah Penumpang Lain
                            </button>
                        </div>

                        <div class="mt-8 pt-6 border-t flex flex-col md:flex-row justify-between items-center gap-4">
                            <div>
                                <p class="text-gray-600 text-sm">Total Pembayaran:</p>
                                <p class="text-2xl font-bold text-blue-600">Rp <span
                                        x-text="(passengers.length * price).toLocaleString('id-ID')"></span></p>
                            </div>
                            <button type="submit"
                                class="w-full md:w-auto bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-10 rounded-lg transition shadow-lg">
                                Lanjut ke Pembayaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Pongo\Herd\SKRIPSIKU\etiketkapalselayar\resources\views/bookings/show.blade.php ENDPATH**/ ?>