<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Transaksi Saya')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-xl font-bold text-gray-900 mb-6">Riwayat Pemesanan Tiket</h3>

                    <?php if($orders->count() > 0): ?>
                        <div class="space-y-4">
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                                    <div class="flex justify-between items-start mb-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Kode Pesanan</p>
                                            <p class="font-mono font-bold text-lg text-gray-900">
                                                <?php echo e($order->order_code); ?></p>
                                        </div>
                                        <div>
                                            <?php if($order->status === 'paid'): ?>
                                                <span
                                                    class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    ✓ Lunas
                                                </span>
                                            <?php elseif($order->status === 'pending'): ?>
                                                <span
                                                    class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                    ⏳ Menunggu Pembayaran
                                                </span>
                                            <?php else: ?>
                                                <span
                                                    class="px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                    ✗ Gagal
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="grid md:grid-cols-2 gap-4 mb-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Kapal</p>
                                            <p class="font-semibold text-gray-900"><?php echo e($order->schedule->ship->name); ?>

                                            </p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Tanggal Keberangkatan</p>
                                            <p class="font-semibold text-gray-900">
                                                <?php echo e(\Carbon\Carbon::parse($order->schedule->departure_date)->format('d M Y')); ?>

                                                -
                                                <?php echo e(\Carbon\Carbon::parse($order->schedule->departure_time)->format('H:i')); ?>

                                                WITA
                                            </p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Jumlah Penumpang</p>
                                            <p class="font-semibold text-gray-900"><?php echo e($order->total_ticket); ?> orang</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Total Pembayaran</p>
                                            <p class="font-bold text-blue-600 text-lg">Rp
                                                <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></p>
                                        </div>
                                    </div>

                                    <div class="border-t pt-4">
                                        <p class="text-sm text-gray-500 mb-2">Daftar Penumpang:</p>
                                        <div class="flex flex-wrap gap-2">
                                            <?php $__currentLoopData = $order->passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="bg-gray-100 px-3 py-1 rounded-full text-sm text-gray-700">
                                                    <?php echo e($passenger->name); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>

                                    <div class="mt-4 flex justify-between items-center">
                                        <p class="text-sm text-gray-500">
                                            Dipesan pada: <?php echo e($order->created_at->format('d M Y H:i')); ?>

                                        </p>
                                        <?php if($order->status === 'pending' && $order->payment): ?>
                                            <a href="<?php echo e(route('bookings.show', $order->schedule)); ?>"
                                                class="text-blue-600 hover:text-blue-800 font-medium text-sm">
                                                Lanjutkan Pembayaran →
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="mt-6">
                            <?php echo e($orders->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-12">
                            <div class="text-6xl mb-4">🎫</div>
                            <h3 class="text-xl font-bold text-gray-900 mb-2">Belum Ada Transaksi</h3>
                            <p class="text-gray-600 mb-6">Anda belum melakukan pemesanan tiket.</p>
                            <a href="<?php echo e(route('bookings.index')); ?>"
                                class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition">
                                Pesan Tiket Sekarang
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Pongo\Herd\SKRIPSIKU\etiketkapalselayar\resources\views/user/transactions.blade.php ENDPATH**/ ?>