<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Status Pembayaran')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-center">
                    <?php if($status == 'success'): ?>
                        <div class="inline-block p-4 bg-green-100 rounded-full mb-6">
                            <span class="text-4xl">✅</span>
                        </div>
                        <h3 class="text-3xl font-bold text-gray-800 mb-2">Pembayaran Berhasil!</h3>
                        <p class="text-gray-600 mb-8">Tiket Anda telah dikonfirmasi. Silakan cek email atau
                            riwayat pesanan Anda.</p>
                    <?php elseif($status == 'pending'): ?>
                        <div class="inline-block p-4 bg-yellow-100 rounded-full mb-6">
                            <span class="text-4xl">🕒</span>
                        </div>
                        <h3 class="text-3xl font-bold text-gray-800 mb-2">Menunggu Pembayaran</h3>
                        <p class="text-gray-600 mb-8">Silakan selesaikan pembayaran Anda sesuai dengan petunjuk
                            di aplikasi Midtrans.</p>
                    <?php else: ?>
                        <div class="inline-block p-4 bg-red-100 rounded-full mb-6">
                            <span class="text-4xl">❌</span>
                        </div>
                        <h3 class="text-3xl font-bold text-gray-800 mb-2">Pembayaran Gagal</h3>
                        <p class="text-gray-600 mb-8">Terjadi kesalahan saat memproses pembayaran. Silakan coba
                            lagi nanti.</p>
                    <?php endif; ?>

                    <a href="<?php echo e(route('bookings.index')); ?>"
                        class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg transition shadow-md">
                        Kembali ke Beranda
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Pongo\Herd\SKRIPSIKU\etiketkapalselayar\resources\views/bookings/finish.blade.php ENDPATH**/ ?>